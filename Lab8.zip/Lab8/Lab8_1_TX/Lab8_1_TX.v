module Lab8_1_TX (
    input wire S1,           // Active-low push button
    output wire laser_tx,    // Assign to PIN_104
    output wire led1         // Active-low LED indicator
);

    // Laser stays ON while S1 is held down (S1 is active-low)
    assign laser_tx = ~S1;

    // LED1 lights up while S1 is held down (active-low LED)
    assign led1 = S1;

endmodule