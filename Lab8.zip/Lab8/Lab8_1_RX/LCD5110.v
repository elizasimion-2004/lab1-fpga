module LCD5110 (
    input  wire clk,
    input  wire sensor,      // iesire modul fotorezistor (1 = lumina)
    output wire ldr_power,
    input  wire S1, S2,      // butoane active LOW (raman functionale)
    input  wire KEY3, KEY4,  // nefolosite, pastrate pentru pinout
    output wire led1, led2, led3,
    output wire buzzer,
    output reg  lcd_rst = 0, lcd_ce = 1,
    output reg  lcd_dc = 0, lcd_din = 0, lcd_clk = 0
);

    reg [7:0] img1 [0:503], img2 [0:503];

    initial begin
        // Imaginea 1: poza (84x48), inclusa direct in cod
        img1[0]=8'h55; img1[1]=8'h88; img1[2]=8'h23; img1[3]=8'h04; img1[4]=8'h55; img1[5]=8'h09; img1[6]=8'hA4; img1[7]=8'h11;
        img1[8]=8'h4A; img1[9]=8'h81; img1[10]=8'h10; img1[11]=8'hA5; img1[12]=8'h49; img1[13]=8'h24; img1[14]=8'h91; img1[15]=8'h04;
        img1[16]=8'hA0; img1[17]=8'h09; img1[18]=8'h40; img1[19]=8'h10; img1[20]=8'h05; img1[21]=8'h50; img1[22]=8'h0B; img1[23]=8'hA4;
        img1[24]=8'h11; img1[25]=8'hC5; img1[26]=8'hE0; img1[27]=8'hF9; img1[28]=8'h7A; img1[29]=8'hFD; img1[30]=8'hDC; img1[31]=8'hFF;
        img1[32]=8'hEE; img1[33]=8'hFF; img1[34]=8'hFF; img1[35]=8'hEF; img1[36]=8'hFF; img1[37]=8'hFF; img1[38]=8'h6F; img1[39]=8'hFE;
        img1[40]=8'h7F; img1[41]=8'hFC; img1[42]=8'h5D; img1[43]=8'hFA; img1[44]=8'hBD; img1[45]=8'hF2; img1[46]=8'hED; img1[47]=8'h54;
        img1[48]=8'hFD; img1[49]=8'h94; img1[50]=8'h7D; img1[51]=8'hB2; img1[52]=8'hEC; img1[53]=8'hD9; img1[54]=8'h78; img1[55]=8'hD5;
        img1[56]=8'hB8; img1[57]=8'hD1; img1[58]=8'h64; img1[59]=8'hC8; img1[60]=8'h11; img1[61]=8'h48; img1[62]=8'h01; img1[63]=8'h40;
        img1[64]=8'h15; img1[65]=8'h40; img1[66]=8'h89; img1[67]=8'h20; img1[68]=8'h4B; img1[69]=8'h90; img1[70]=8'h01; img1[71]=8'hA4;
        img1[72]=8'h11; img1[73]=8'h48; img1[74]=8'h01; img1[75]=8'h50; img1[76]=8'h25; img1[77]=8'h80; img1[78]=8'h29; img1[79]=8'h40;
        img1[80]=8'h95; img1[81]=8'h20; img1[82]=8'h45; img1[83]=8'hA8; img1[84]=8'hEA; img1[85]=8'h04; img1[86]=8'hB0; img1[87]=8'h45;
        img1[88]=8'hB0; img1[89]=8'h45; img1[90]=8'h98; img1[91]=8'h62; img1[92]=8'h88; img1[93]=8'h72; img1[94]=8'h80; img1[95]=8'h14;
        img1[96]=8'hE1; img1[97]=8'h0A; img1[98]=8'hF4; img1[99]=8'h80; img1[100]=8'h2A; img1[101]=8'h41; img1[102]=8'h14; img1[103]=8'h81;
        img1[104]=8'h2A; img1[105]=8'h01; img1[106]=8'h48; img1[107]=8'h36; img1[108]=8'h40; img1[109]=8'h3F; img1[110]=8'hBF; img1[111]=8'h5F;
        img1[112]=8'h7B; img1[113]=8'hFF; img1[114]=8'hDF; img1[115]=8'hFD; img1[116]=8'hFF; img1[117]=8'hAE; img1[118]=8'h5F; img1[119]=8'hA3;
        img1[120]=8'h5C; img1[121]=8'hA7; img1[122]=8'h59; img1[123]=8'h26; img1[124]=8'h55; img1[125]=8'hAB; img1[126]=8'h15; img1[127]=8'hEA;
        img1[128]=8'h97; img1[129]=8'h64; img1[130]=8'hDB; img1[131]=8'h67; img1[132]=8'h5D; img1[133]=8'hEB; img1[134]=8'h4F; img1[135]=8'hBB;
        img1[136]=8'h4E; img1[137]=8'hBD; img1[138]=8'h0F; img1[139]=8'h7A; img1[140]=8'h17; img1[141]=8'hFD; img1[142]=8'h1E; img1[143]=8'hFB;
        img1[144]=8'hD5; img1[145]=8'hF6; img1[146]=8'hC8; img1[147]=8'h91; img1[148]=8'h4A; img1[149]=8'h08; img1[150]=8'h52; img1[151]=8'h15;
        img1[152]=8'h88; img1[153]=8'h12; img1[154]=8'h24; img1[155]=8'h48; img1[156]=8'h85; img1[157]=8'h10; img1[158]=8'hA5; img1[159]=8'h0A;
        img1[160]=8'hA0; img1[161]=8'h0A; img1[162]=8'hA5; img1[163]=8'h08; img1[164]=8'hA2; img1[165]=8'h0D; img1[166]=8'h50; img1[167]=8'h86;
        img1[168]=8'hFE; img1[169]=8'hFE; img1[170]=8'h76; img1[171]=8'hFE; img1[172]=8'hDE; img1[173]=8'h76; img1[174]=8'hFC; img1[175]=8'hBA;
        img1[176]=8'hEC; img1[177]=8'hFA; img1[178]=8'h58; img1[179]=8'hFA; img1[180]=8'hB0; img1[181]=8'hE2; img1[182]=8'h84; img1[183]=8'h48;
        img1[184]=8'h11; img1[185]=8'h42; img1[186]=8'h14; img1[187]=8'h80; img1[188]=8'h55; img1[189]=8'h00; img1[190]=8'hA9; img1[191]=8'h04;
        img1[192]=8'hA1; img1[193]=8'h08; img1[194]=8'h52; img1[195]=8'h04; img1[196]=8'h51; img1[197]=8'h04; img1[198]=8'h28; img1[199]=8'h81;
        img1[200]=8'h1F; img1[201]=8'hD5; img1[202]=8'h3B; img1[203]=8'hE6; img1[204]=8'h5D; img1[205]=8'hAA; img1[206]=8'h75; img1[207]=8'h88;
        img1[208]=8'h23; img1[209]=8'h14; img1[210]=8'hEB; img1[211]=8'h14; img1[212]=8'hBB; img1[213]=8'h65; img1[214]=8'h9A; img1[215]=8'h75;
        img1[216]=8'h9A; img1[217]=8'h54; img1[218]=8'hBB; img1[219]=8'h44; img1[220]=8'h9B; img1[221]=8'h24; img1[222]=8'h51; img1[223]=8'h8A;
        img1[224]=8'h25; img1[225]=8'h50; img1[226]=8'h8D; img1[227]=8'h77; img1[228]=8'h85; img1[229]=8'h5F; img1[230]=8'hA2; img1[231]=8'h1B;
        img1[232]=8'h68; img1[233]=8'h00; img1[234]=8'h15; img1[235]=8'h40; img1[236]=8'h14; img1[237]=8'h81; img1[238]=8'h2A; img1[239]=8'h00;
        img1[240]=8'hAA; img1[241]=8'h00; img1[242]=8'h2A; img1[243]=8'h40; img1[244]=8'h0A; img1[245]=8'h50; img1[246]=8'h02; img1[247]=8'h54;
        img1[248]=8'h00; img1[249]=8'h55; img1[250]=8'h00; img1[251]=8'hAA; img1[252]=8'hFF; img1[253]=8'hFF; img1[254]=8'hB7; img1[255]=8'hFD;
        img1[256]=8'hEF; img1[257]=8'h7F; img1[258]=8'hDB; img1[259]=8'hFF; img1[260]=8'hF6; img1[261]=8'hFF; img1[262]=8'hDB; img1[263]=8'hFF;
        img1[264]=8'h6F; img1[265]=8'hFA; img1[266]=8'hBF; img1[267]=8'hF6; img1[268]=8'hF0; img1[269]=8'h01; img1[270]=8'h64; img1[271]=8'h80;
        img1[272]=8'h8A; img1[273]=8'h20; img1[274]=8'hC2; img1[275]=8'h08; img1[276]=8'h52; img1[277]=8'h80; img1[278]=8'h15; img1[279]=8'h00;
        img1[280]=8'h89; img1[281]=8'h20; img1[282]=8'h82; img1[283]=8'h58; img1[284]=8'hA2; img1[285]=8'h15; img1[286]=8'hE9; img1[287]=8'h06;
        img1[288]=8'hF9; img1[289]=8'h92; img1[290]=8'hE5; img1[291]=8'h58; img1[292]=8'hD2; img1[293]=8'hD5; img1[294]=8'h38; img1[295]=8'hC2;
        img1[296]=8'h35; img1[297]=8'h88; img1[298]=8'h75; img1[299]=8'h82; img1[300]=8'hF4; img1[301]=8'h01; img1[302]=8'hF4; img1[303]=8'h02;
        img1[304]=8'hA8; img1[305]=8'h55; img1[306]=8'h48; img1[307]=8'h92; img1[308]=8'h25; img1[309]=8'hDA; img1[310]=8'h20; img1[311]=8'h9B;
        img1[312]=8'h64; img1[313]=8'h42; img1[314]=8'hF9; img1[315]=8'hF4; img1[316]=8'hEF; img1[317]=8'hDF; img1[318]=8'hEF; img1[319]=8'hBE;
        img1[320]=8'hDA; img1[321]=8'hFE; img1[322]=8'h7C; img1[323]=8'hFD; img1[324]=8'hFC; img1[325]=8'h78; img1[326]=8'hE9; img1[327]=8'hF4;
        img1[328]=8'hE1; img1[329]=8'hD8; img1[330]=8'hA2; img1[331]=8'hC1; img1[332]=8'h08; img1[333]=8'hFA; img1[334]=8'hF8; img1[335]=8'hFA;
        img1[336]=8'hFF; img1[337]=8'hFF; img1[338]=8'hF7; img1[339]=8'hDE; img1[340]=8'h7F; img1[341]=8'hEB; img1[342]=8'hFF; img1[343]=8'hBF;
        img1[344]=8'hFE; img1[345]=8'hF7; img1[346]=8'hFE; img1[347]=8'h6F; img1[348]=8'hFF; img1[349]=8'hDB; img1[350]=8'h7F; img1[351]=8'hF6;
        img1[352]=8'hDF; img1[353]=8'hFE; img1[354]=8'hA1; img1[355]=8'h5C; img1[356]=8'hA1; img1[357]=8'h4A; img1[358]=8'h30; img1[359]=8'hE5;
        img1[360]=8'h02; img1[361]=8'hE8; img1[362]=8'h13; img1[363]=8'hE4; img1[364]=8'h52; img1[365]=8'hD5; img1[366]=8'hB0; img1[367]=8'hD4;
        img1[368]=8'hFB; img1[369]=8'h74; img1[370]=8'hCB; img1[371]=8'hB5; img1[372]=8'h43; img1[373]=8'hBE; img1[374]=8'h49; img1[375]=8'hB2;
        img1[376]=8'h36; img1[377]=8'hE9; img1[378]=8'h12; img1[379]=8'hAB; img1[380]=8'h54; img1[381]=8'h89; img1[382]=8'h25; img1[383]=8'hC9;
        img1[384]=8'h13; img1[385]=8'hEC; img1[386]=8'h81; img1[387]=8'h7E; img1[388]=8'h81; img1[389]=8'hFA; img1[390]=8'h05; img1[391]=8'hFA;
        img1[392]=8'hA1; img1[393]=8'hDE; img1[394]=8'h69; img1[395]=8'hD6; img1[396]=8'hE9; img1[397]=8'hBE; img1[398]=8'h77; img1[399]=8'hCF;
        img1[400]=8'hFA; img1[401]=8'hFD; img1[402]=8'hB6; img1[403]=8'hFF; img1[404]=8'h6A; img1[405]=8'hB7; img1[406]=8'h7D; img1[407]=8'hCB;
        img1[408]=8'h3B; img1[409]=8'hEF; img1[410]=8'h5F; img1[411]=8'hFD; img1[412]=8'hFF; img1[413]=8'hEF; img1[414]=8'hFF; img1[415]=8'hFD;
        img1[416]=8'hFB; img1[417]=8'h5C; img1[418]=8'hFB; img1[419]=8'hEE; img1[420]=8'hFF; img1[421]=8'hDF; img1[422]=8'h7E; img1[423]=8'hF7;
        img1[424]=8'h5F; img1[425]=8'hFB; img1[426]=8'hEF; img1[427]=8'hBF; img1[428]=8'hFF; img1[429]=8'hD7; img1[430]=8'hFD; img1[431]=8'hFF;
        img1[432]=8'hD7; img1[433]=8'hFD; img1[434]=8'hEF; img1[435]=8'h7F; img1[436]=8'hFD; img1[437]=8'hDF; img1[438]=8'hF7; img1[439]=8'h58;
        img1[440]=8'hFF; img1[441]=8'h75; img1[442]=8'hDB; img1[443]=8'hFF; img1[444]=8'hF6; img1[445]=8'hDD; img1[446]=8'h6B; img1[447]=8'hF6;
        img1[448]=8'hDB; img1[449]=8'hED; img1[450]=8'hFF; img1[451]=8'hF5; img1[452]=8'hFF; img1[453]=8'hBB; img1[454]=8'hFF; img1[455]=8'hDF;
        img1[456]=8'hFA; img1[457]=8'h7D; img1[458]=8'hAE; img1[459]=8'h7A; img1[460]=8'h7D; img1[461]=8'hEE; img1[462]=8'h79; img1[463]=8'hFE;
        img1[464]=8'hDA; img1[465]=8'hFC; img1[466]=8'h77; img1[467]=8'hFC; img1[468]=8'hBF; img1[469]=8'hF6; img1[470]=8'hBD; img1[471]=8'h5F;
        img1[472]=8'h6E; img1[473]=8'h97; img1[474]=8'hFF; img1[475]=8'hE5; img1[476]=8'hBB; img1[477]=8'h7E; img1[478]=8'hEB; img1[479]=8'hF7;
        img1[480]=8'hFA; img1[481]=8'h7D; img1[482]=8'hBF; img1[483]=8'hDF; img1[484]=8'hEE; img1[485]=8'hF7; img1[486]=8'hBD; img1[487]=8'hD7;
        img1[488]=8'h79; img1[489]=8'hCF; img1[490]=8'h7A; img1[491]=8'hAD; img1[492]=8'hDB; img1[493]=8'hF6; img1[494]=8'hEF; img1[495]=8'hFD;
        img1[496]=8'hD7; img1[497]=8'hEF; img1[498]=8'h7B; img1[499]=8'hF7; img1[500]=8'hBD; img1[501]=8'h7F; img1[502]=8'hDA; img1[503]=8'hEF;

        // Imaginea 2: din fisier extern
        $readmemh("imagine2.hex", img2);
    end

    function [7:0] cmd;
        input [2:0] n;
        begin
            case (n)
                0: cmd=8'h21; 1: cmd=8'hB8;
                2: cmd=8'h04; 3: cmd=8'h14;
                4: cmd=8'h20; 5: cmd=8'h0C;
                6: cmd=8'h80; 7: cmd=8'h40;
                default: cmd=8'h00;
            endcase
        end
    endfunction

    // ---------------- Senzor de lumina ----------------
    assign ldr_power = 1'b1;
    assign buzzer    = 1'b1;          // buzzer oprit

    reg [1:0]  light_sync   = 2'b00;  // sincronizare 2 FF
    reg        light_stable = 1'b0;   // valoare filtrata (debounce)
    reg        light_prev   = 1'b0;
    reg [19:0] deb_cnt      = 0;      // ~21 ms la 50 MHz

    always @(posedge clk) begin
        light_sync <= {light_sync[0], sensor};

        // semnalul trebuie sa fie stabil 2^20 tacti ca sa fie acceptat
        if (light_sync[1] != light_stable) begin
            deb_cnt <= deb_cnt + 1'b1;
            if (&deb_cnt) begin
                light_stable <= light_sync[1];
                deb_cnt <= 0;
            end
        end
        else
            deb_cnt <= 0;

        light_prev <= light_stable;
    end

    wire light_rise = light_stable & ~light_prev;  // tocmai s-a detectat lumina

    // LED-uri active LOW (ca in codul original)
    assign led1 = ~light_stable;      // lumina detectata
    assign led3 =  light_stable;      // intuneric
    // led2 este definit mai jos: aprins cand e afisata imaginea 2

    // ---------------- Butoane ----------------
    reg [1:0] b1 = 2'b11, b2 = 2'b11;

    always @(posedge clk) begin
        b1 <= {b1[0], S1};
        b2 <= {b2[0], S2};
    end

    // ---------------- LCD ----------------
    reg selected = 0, done = 0;
    reg want = 0;                     // imaginea care ar trebui afisata
    reg [21:0] startup = 0;
    reg [6:0] div = 0;
    reg [9:0] index = 0;
    reg [7:0] shift = 0;
    reg [2:0] bit_no = 7;
    reg [1:0] state = 0;

    assign led2 = ~selected;

    wire startup_done = (startup == 22'd2500000);

    wire [9:0] pixel_index = index - 10'd8;

    wire [7:0] data_byte = (index < 8) ?
        cmd(index[2:0]) :
        selected ? img2[pixel_index] : img1[pixel_index];

    always @(posedge clk) begin

        // Cererea de schimbare: lumina -> comuta imaginea,
        // S1 -> imaginea 1, S2 -> imaginea 2.
        // Se memoreaza chiar daca LCD-ul e in mijlocul unei redesenari.
        if (startup_done) begin
            if (light_rise)
                want <= ~want;
            else if (!b1[1])
                want <= 1'b0;
            else if (!b2[1])
                want <= 1'b1;
        end

        if (!startup_done) begin
            startup <= startup + 1'b1;
            if (startup == 22'd1000000)
                lcd_rst <= 1'b1;
        end

        // Redesenare cand imaginea dorita difera de cea afisata
        else if (done) begin
            if (selected != want) begin
                selected <= want;
                index <= 6;           // retrimite set X=0 / set Y=0, apoi pixelii
                done <= 0;
            end
        end

        else if (div == 7'd99) begin
            div <= 0;

            case (state)
                0: begin
                    lcd_ce <= 0;
                    lcd_dc <= (index >= 8);
                    lcd_din <= data_byte[7];
                    shift <= data_byte;
                    bit_no <= 7;
                    state <= 1;
                end

                1: begin
                    lcd_clk <= 1;
                    state <= 2;
                end

                2: begin
                    lcd_clk <= 0;
                    if (bit_no == 0)
                        state <= 3;
                    else begin
                        bit_no <= bit_no - 1'b1;
                        lcd_din <= shift[6];
                        shift <= {shift[6:0],1'b0};
                        state <= 1;
                    end
                end

                3: begin
                    lcd_ce <= 1;
                    if (index == 511)
                        done <= 1;
                    else
                        index <= index + 1'b1;
                    state <= 0;
                end
            endcase
        end
        else
            div <= div + 1'b1;
    end

endmodule
