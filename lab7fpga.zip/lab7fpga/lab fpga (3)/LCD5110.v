module LCD5110 (
    input  wire clk,
    output reg lcd_rst = 0,
    output reg lcd_ce  = 1,
    output reg lcd_dc  = 0,
    output reg lcd_din = 0,
    output reg lcd_clk = 0
);

    // Nokia 5110 - PCD8544
    // FPGA clock: 50 MHz

    function [7:0] init_byte;
        input [2:0] n;
        begin
            case (n)
                0: init_byte = 8'h21;
                1: init_byte = 8'hB8;
                2: init_byte = 8'h04;
                3: init_byte = 8'h14;
                4: init_byte = 8'h20;
                5: init_byte = 8'h0C;
                6: init_byte = 8'h80;
                7: init_byte = 8'h40;
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    // Font 5x7
    // Randul 1 (n = 0..41):   TEO ELI
    // Randul 2 (n = 64..105): SI DAVI
    function [7:0] text_byte;
        input [6:0] n;
        begin
            case (n)

                // ===== RAND 1: TEO ELI =====

                // T
                 0: text_byte = 8'h01;
                 1: text_byte = 8'h01;
                 2: text_byte = 8'h7F;
                 3: text_byte = 8'h01;
                 4: text_byte = 8'h01;

                // E
                 6: text_byte = 8'h7F;
                 7: text_byte = 8'h49;
                 8: text_byte = 8'h49;
                 9: text_byte = 8'h49;
                10: text_byte = 8'h41;

                // O
                12: text_byte = 8'h3E;
                13: text_byte = 8'h41;
                14: text_byte = 8'h41;
                15: text_byte = 8'h41;
                16: text_byte = 8'h3E;

                // spatiu (18..22 raman 0)

                // E
                24: text_byte = 8'h7F;
                25: text_byte = 8'h49;
                26: text_byte = 8'h49;
                27: text_byte = 8'h49;
                28: text_byte = 8'h41;

                // L
                30: text_byte = 8'h7F;
                31: text_byte = 8'h40;
                32: text_byte = 8'h40;
                33: text_byte = 8'h40;
                34: text_byte = 8'h40;

                // I
                36: text_byte = 8'h00;
                37: text_byte = 8'h41;
                38: text_byte = 8'h7F;
                39: text_byte = 8'h41;
                40: text_byte = 8'h00;

                // ===== RAND 2: DAVI =====

                // D
                82: text_byte = 8'h7F;
                83: text_byte = 8'h41;
                84: text_byte = 8'h41;
                85: text_byte = 8'h22;
                86: text_byte = 8'h1C;

                // A
                88: text_byte = 8'h7E;
                89: text_byte = 8'h11;
                90: text_byte = 8'h11;
                91: text_byte = 8'h11;
                92: text_byte = 8'h7E;

                // V
                94: text_byte = 8'h1F;
                95: text_byte = 8'h20;
                96: text_byte = 8'h40;
                97: text_byte = 8'h20;
                98: text_byte = 8'h1F;

                // I
               100: text_byte = 8'h00;
               101: text_byte = 8'h41;
               102: text_byte = 8'h7F;
               103: text_byte = 8'h41;
               104: text_byte = 8'h00;

                // Spatii intre litere
                default: text_byte = 8'h00;

            endcase
        end
    endfunction

    // 0 = initializare
    // 1 = stergere ecran
    // 2 = pozitionare cursor rand 1 (X=21, bank 2)
    // 3 = text rand 1: TEO ELI
    // 4 = pozitionare cursor rand 2 (X=21, bank 3)
    // 5 = text rand 2: SI DAVI

    reg [2:0] phase = 0;
    reg [9:0] pos = 0;

    wire [7:0] tx_byte =
        (phase == 0) ? init_byte(pos[2:0]) :
        (phase == 1) ? 8'h00 :
        (phase == 2) ? ((pos == 0) ? 8'h95 : 8'h42) :
        (phase == 3) ? text_byte({1'b0, pos[5:0]}) :
        (phase == 4) ? ((pos == 0) ? 8'h95 : 8'h43) :
                       text_byte({1'b1, pos[5:0]});

    localparam RESET_LOW  = 0;
    localparam RESET_HIGH = 1;
    localparam LOAD       = 2;
    localparam CLOCK_UP   = 3;
    localparam CLOCK_DOWN = 4;
    localparam BYTE_END   = 5;
    localparam ADVANCE    = 6;
    localparam DONE       = 7;

    reg [3:0] state = RESET_LOW;
    reg [21:0] timer = 0;
    reg [5:0] spi_div = 0;
    reg [7:0] shift_byte = 0;
    reg [2:0] bit_index = 0;

    always @(posedge clk) begin
        case (state)

            RESET_LOW: begin
                lcd_rst <= 0;
                lcd_ce <= 1;
                lcd_clk <= 0;

                if (timer == 22'd999999) begin
                    timer <= 0;
                    lcd_rst <= 1;
                    state <= RESET_HIGH;
                end
                else
                    timer <= timer + 1'b1;
            end

            RESET_HIGH: begin
                if (timer == 22'd2499999) begin
                    timer <= 0;
                    state <= LOAD;
                end
                else
                    timer <= timer + 1'b1;
            end

            LOAD: begin
                lcd_ce <= 0;
                // fazele 1, 3, 5 = date (DC=1); 0, 2, 4 = comenzi (DC=0)
                lcd_dc <= phase[0];
                lcd_clk <= 0;
                lcd_din <= tx_byte[7];

                shift_byte <= tx_byte;
                bit_index <= 7;
                spi_div <= 0;
                state <= CLOCK_UP;
            end

            CLOCK_UP: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 1;
                    state <= CLOCK_DOWN;
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            CLOCK_DOWN: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 0;

                    if (bit_index == 0)
                        state <= BYTE_END;
                    else begin
                        bit_index <= bit_index - 1'b1;
                        lcd_din <= shift_byte[6];
                        shift_byte <=
                            {shift_byte[6:0], 1'b0};
                        state <= CLOCK_UP;
                    end
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            BYTE_END: begin
                lcd_ce <= 1;
                state <= ADVANCE;
            end

            ADVANCE: begin

                if (phase == 5 && pos == 41)
                    state <= DONE;

                else begin
                    state <= LOAD;

                    if (phase == 0 && pos == 7) begin
                        phase <= 1;
                        pos <= 0;
                    end

                    else if (phase == 1 && pos == 503) begin
                        phase <= 2;
                        pos <= 0;
                    end

                    else if (phase == 2 && pos == 1) begin
                        phase <= 3;
                        pos <= 0;
                    end

                    else if (phase == 3 && pos == 41) begin
                        phase <= 4;
                        pos <= 0;
                    end

                    else if (phase == 4 && pos == 1) begin
                        phase <= 5;
                        pos <= 0;
                    end

                    else
                        pos <= pos + 1'b1;
                end
            end

            DONE: begin
                lcd_ce <= 1;
                lcd_clk <= 0;
            end

            default:
                state <= RESET_LOW;

        endcase
    end

endmodule